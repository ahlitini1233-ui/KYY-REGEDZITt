plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.kyy.regedzit"
    compileSdk = 35
    defaultConfig { applicationId = "com.kyy.regedzit"; minSdk = 26; targetSdk = 35; versionCode = 2; versionName = "1.1" }
}
