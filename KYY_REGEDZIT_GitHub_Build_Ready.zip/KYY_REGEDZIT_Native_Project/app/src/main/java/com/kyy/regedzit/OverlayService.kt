package com.kyy.regedzit

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import kotlin.math.abs

class OverlayService : Service(), Choreographer.FrameCallback {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var crosshair: TextView? = null
    private var fpsText: TextView? = null
    private var frames = 0
    private var last = 0L
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun lp(w: Int, h: Int): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(w, h, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val channel = "kyy_overlay"
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(channel, "KYY REGEDZIT", NotificationManager.IMPORTANCE_LOW))
        val n = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channel).setContentTitle("KYY REGEDZIT aktif").setContentText("Floating panel berjalan").setSmallIcon(android.R.drawable.ic_menu_view).build()
        else Notification.Builder(this).setContentTitle("KYY REGEDZIT aktif").setSmallIcon(android.R.drawable.ic_menu_view).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(21, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(21, n)
        addBubble()
        Choreographer.getInstance().postFrameCallback(this)
    }

    private fun addBubble() {
        val v = TextView(this).apply {
            text = "K"; textSize = 21f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF101A35.toInt()); setStroke(dp(2), 0xFF36E5FF.toInt()) }
        }
        val p = lp(dp(58), dp(58)).apply { x = dp(16); y = dp(190) }
        v.setOnTouchListener(object : View.OnTouchListener {
            var sx=0f; var sy=0f; var ox=0; var oy=0; var moved=false
            override fun onTouch(view: View, e: MotionEvent): Boolean {
                when(e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx=(e.rawX-sx).toInt(); val dy=(e.rawY-sy).toInt()
                        if(abs(dx)+abs(dy)>dp(7)) moved=true
                        p.x=ox+dx; p.y=oy+dy
                        try { wm.updateViewLayout(v,p) } catch (_: Exception) {}
                        return true
                    }
                    MotionEvent.ACTION_UP -> { if(!moved) togglePanel(); return true }
                }
                return false
            }
        })
        bubble=v; wm.addView(v,p)
    }

    private fun togglePanel() {
        if(panel != null) { removePanel(); return }
        val box=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(dp(12),dp(12),dp(12),dp(12))
            background=GradientDrawable().apply { setColor(0xF2111A31.toInt()); cornerRadius=dp(16).toFloat(); setStroke(dp(1),0xFF36E5FF.toInt()) }
        }
        box.addView(TextView(this).apply { text="KYY REGEDZIT"; textSize=18f; gravity=Gravity.CENTER; setTextColor(0xFF36E5FF.toInt()) })
        box.addView(Button(this).apply { text="CROSSHAIR ON / OFF"; setOnClickListener { toggleCrosshair() } })
        fpsText=TextView(this).apply { text="Overlay callback FPS: --"; setTextColor(Color.WHITE); setPadding(4,dp(8),4,dp(8)) }
        box.addView(fpsText)
        box.addView(Button(this).apply { text="TUTUP PANEL"; setOnClickListener { removePanel() } })
        panel=box
        wm.addView(box,lp(dp(270),WindowManager.LayoutParams.WRAP_CONTENT).apply { x=dp(82); y=dp(180) })
    }

    private fun toggleCrosshair() {
        if(crosshair != null) {
            try { wm.removeView(crosshair) } catch (_: Exception) {}
            crosshair=null
        } else {
            val marker=TextView(this).apply {
                text="+"; textSize=42f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER
                setTextColor(0xFF36E5FF.toInt()); setShadowLayer(dp(8).toFloat(),0f,0f,0xFF36E5FF.toInt())
            }
            val p=lp(dp(64),dp(64)).apply {
                gravity=Gravity.CENTER
                flags=flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            }
            crosshair=marker; wm.addView(marker,p)
        }
    }

    override fun doFrame(frameTimeNanos: Long) {
        frames++
        val now=System.currentTimeMillis()
        if(last==0L) last=now
        if(now-last>=1000L) {
            fpsText?.text="Overlay callback: $frames FPS (bukan FPS game)"
            frames=0; last=now
        }
        Choreographer.getInstance().postFrameCallback(this)
    }

    private fun removePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel=null
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int)=START_STICKY
    override fun onDestroy() {
        Choreographer.getInstance().removeFrameCallback(this)
        removePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        crosshair?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
