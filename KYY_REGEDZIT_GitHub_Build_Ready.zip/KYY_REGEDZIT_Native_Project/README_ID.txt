KYY REGEDZIT — Native Android + HTML WebView

Termasuk:
- HTML KYY REGEDZIT di dalam aplikasi melalui WebView.
- Floating bubble native yang dapat digeser di atas aplikasi lain.
- Menu overlay native untuk menampilkan/menyembunyikan crosshair visual.
- Penghitung callback frame overlay (bukan FPS internal game).

Batasan:
- Auto HS dan Auto Lock di HTML hanya simulator UI, tidak mengendalikan game.
- Crosshair merupakan penanda visual statis, bukan aim assist.
- Callback FPS bukan pengukuran FPS internal game.
- Overlay Android memerlukan izin "Display over other apps".

Build:
1. Ekstrak ZIP dan buka folder ini di Android Studio.
2. Gunakan JDK 17 dan pasang Android SDK Platform 35.
3. Tunggu Gradle Sync.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Instal APK, buka aplikasi, tekan AKTIFKAN FLOATING OVERLAY.
6. Izinkan Display over other apps. Kembali ke aplikasi dan tekan tombol tersebut lagi.
